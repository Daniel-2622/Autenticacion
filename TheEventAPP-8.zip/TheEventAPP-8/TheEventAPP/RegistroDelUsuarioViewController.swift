//
//  RegistroDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class RegistroDelUsuarioViewController: UIViewController, UITextFieldDelegate {
    
    
    @IBOutlet weak var Usuario: UITextField!
    @IBOutlet weak var Correo: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    @IBOutlet weak var Imagen: UIImageView!
    @IBOutlet weak var cambiarImagen: UIButton!
    @IBOutlet weak var Aviso: UILabel!
    
    
    var imagePicker: UIImagePickerController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.Usuario.delegate = self
        self.Correo.delegate = self
        self.Contraseña.delegate = self
        
       let imageTap = UITapGestureRecognizer(target: self, action: #selector(openImagePicker))
       Imagen.isUserInteractionEnabled = true
       Imagen.addGestureRecognizer(imageTap)
       Imagen.clipsToBounds = true
        
       imagePicker = UIImagePickerController()
       imagePicker.allowsEditing = true
       imagePicker.sourceType = .photoLibrary
       imagePicker.delegate = self
    }
    
    @objc func openImagePicker(_ sender:Any) {
        self.present(imagePicker, animated: true, completion: nil)
    }
    
    @IBAction func botonRegistro(_ sender: UIButton) {
            Auth.auth().createUser(withEmail: Correo.text!, password: Contraseña.text!) { (user, error)  in
                if error == nil && user != nil
                {
                    print("Usuario creado")
                    
                    self.Aviso.text = "User created successfully."
                    
            let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = self.Usuario.text!
                }else{
                    self.Aviso.textColor = UIColor.red
                    self.Aviso.text = ("\(error!.localizedDescription)")
                }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Usuario.resignFirstResponder()
        Correo.resignFirstResponder()
        Contraseña.resignFirstResponder()
        return (true)
    }
}
    
 extension RegistroDelUsuarioViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate {
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true, completion: nil)
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
            
            if let pickedImage = info[UIImagePickerControllerEditedImage] as? UIImage {
                self.Imagen.image = pickedImage
            }
            
            picker.dismiss(animated: true, completion: nil)
        }
        
    }

