//
//  RegistroDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit
import Firebase

class RegistroDelUsuarioViewController: UIViewController, UITextFieldDelegate{
    
    
    @IBOutlet weak var Usuario: UITextField!
    @IBOutlet weak var Correo: UITextField!
    @IBOutlet weak var Contraseña: UITextField!
    @IBOutlet weak var Aviso: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.Usuario.delegate = self
        self.Correo.delegate = self
        self.Contraseña.delegate = self
    }
    
    @IBAction func botonRegistro(_ sender: UIButton) {
            Auth.auth().createUser(withEmail: Correo.text!, password: Contraseña.text!) { (user, error)  in
                if error == nil && user != nil
                {
                    print("Usuario creado")
                    
                    self.Aviso.text = "User created successfully."
                    
            let changeRequest = Auth.auth().currentUser?.createProfileChangeRequest()
                changeRequest?.displayName = self.Usuario.text!
                }else{
                    self.Aviso.textColor = UIColor.red
                    self.Aviso.text = ("\(error!.localizedDescription)")
                }
        }
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Usuario.resignFirstResponder()
        Correo.resignFirstResponder()
        Contraseña.resignFirstResponder()
        return (true)
    }
}
