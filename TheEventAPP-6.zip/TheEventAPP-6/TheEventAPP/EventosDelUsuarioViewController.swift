//
//  EventosDelUsuarioViewController.swift
//  TheEventAPP
//
//  Created by Usuario invitado on 30/10/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class EventosDelUsuarioViewController: UIViewController,UITextFieldDelegate{
    
    
    @IBOutlet weak var Email: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

      //  self.Email.delegate = self
       // self.Password.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
//Ocultar con tocar pantalla
   override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
//Ocultar con enter
   func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        Email.resignFirstResponder()
        Password.resignFirstResponder()
        return (true)
    }
 }
