//
//  TodosLosEventosViewController.swift
//  TheEventAPP
//
//  Created by Macbook on 11/22/18.
//  Copyright © 2018 Usuario invitado. All rights reserved.
//

import UIKit

class TodosLosEventosViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tablaDeTodos: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tablaDeTodos.delegate = self
        tablaDeTodos.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cel = tablaDeTodos.dequeueReusableCell(withIdentifier: "eventos", for: indexPath)
            cel.backgroundColor = UIColor.orange.withAlphaComponent(0.4)
            cel.textLabel?.text = "Soy la celda mas verguera la numero \(indexPath.row) neta"
            cel.layer.borderWidth = 1
            cel.layer.cornerRadius = 10
            cel.imageView?.layer.cornerRadius = 20
            cel.imageView?.layer.borderWidth = 2
            return cel
    }
    

}
